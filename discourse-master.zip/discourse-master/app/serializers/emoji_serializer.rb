class EmojiSerializer < ApplicationSerializer
  attributes :name, :url
end
