class BackupSerializer < ApplicationSerializer
  attributes :filename, :size, :link
end
