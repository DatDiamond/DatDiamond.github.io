window.ENV = { };

window.Discourse = {};
Discourse.SiteSettings = {};

window.EmberENV = window.EmberENV || {};
window.EmberENV['FORCE_JQUERY'] = true;

