/**
  A trivial model we use to handle input validation

  @class InputValidation
  @extends Discourse.Model
  @namespace Discourse
  @module Discourse
**/
Discourse.InputValidation = Discourse.Model.extend({});


